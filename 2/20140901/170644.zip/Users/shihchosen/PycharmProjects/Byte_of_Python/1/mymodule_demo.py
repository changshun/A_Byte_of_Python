__author__ = 'shihchosen'
import mymodule

mymodule.sayhi()
print('Version', mymodule.__version__)