__author__ = 'shihchosen'
from mymodule import sayhi, __version__

sayhi()
print('Version', __version__)