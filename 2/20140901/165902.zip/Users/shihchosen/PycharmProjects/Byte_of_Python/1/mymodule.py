__author__ = 'shihchosen'
def sayhi():
    print('Hi, this is mymodule speaking.')
__version__='0.1'